Template ini tidak boleh dijual. Jika Anda ingin mendistribusikan ulang template ini, mohon biarkan konten folder dan keadaan file seperti apa adanya dan jangan dimodifikasi.

Pengecualian bagi pemakai template ini. Anda yang memakai template ini diperbolehkan untuk memodifikasi dan menghapus atribusi apapun di dalam template ini. Yang penting jangan menambahkan atribusi palsu.

28 Mei 2013, http://gplus.to/tovic